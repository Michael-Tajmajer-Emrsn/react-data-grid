module.exports = {
  SimpleCellFormatter: require('./SimpleCellFormatter')
};
