import AppConstants from '../AppConstants';

describe('AppConstants test', () => {
  it('should import AppConstants', () => {
    expect(AppConstants).toBeDefined();
  });
});
