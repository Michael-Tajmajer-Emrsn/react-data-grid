export const DragItemTypes = {
  Column: 'column'
};
