import { Map } from 'immutable';

module.exports = Map.isMap;
