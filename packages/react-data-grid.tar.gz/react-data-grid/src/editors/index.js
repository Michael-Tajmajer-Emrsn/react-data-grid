module.exports = {
  CheckboxEditor: require('./CheckboxEditor'),
  EditorBase: require('./EditorBase'),
  SimpleTextEditor: require('./SimpleTextEditor')
};
