import ExcelColumn from './ExcelColumn';

export default { ExcelColumn };
