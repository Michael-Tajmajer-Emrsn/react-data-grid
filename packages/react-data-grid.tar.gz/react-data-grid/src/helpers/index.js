import GridPropHelpers from './test/GridPropHelpers';

module.exports = {
  test: { GridPropHelpers }
};
