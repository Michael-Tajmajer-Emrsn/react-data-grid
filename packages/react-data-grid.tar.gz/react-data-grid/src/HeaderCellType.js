const HeaderCellType = {
  SORTABLE: 0,
  FILTERABLE: 1,
  NONE: 2,
  CHECKBOX: 3
};

module.exports = HeaderCellType;
