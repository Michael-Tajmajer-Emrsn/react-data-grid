module.exports = {
  Selectors: require('./Selectors')
};
