import React from 'react';
import AutoCompleteFilter from './AutoCompleteFilter';

export default (props) => {
  return <AutoCompleteFilter {...props} multiSelection={false} />;
};

